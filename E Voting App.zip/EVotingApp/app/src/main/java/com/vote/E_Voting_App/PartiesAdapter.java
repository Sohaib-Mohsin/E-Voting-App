package com.vote.E_Voting_App;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class PartiesAdapter extends RecyclerView.Adapter<PartiesAdapter.ViewHolder> {

    Context context;
    ArrayList<Parties_Model> parties_modelArrayList;
    String Votes = "0";
    AlertDialog dialog;

    public PartiesAdapter(Context context, ArrayList<Parties_Model> parties_modelArrayList) {
        this.context = context;
        this.parties_modelArrayList = parties_modelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.parties_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Parties_Model parties_model = parties_modelArrayList.get(position);
        holder.Name.setText(parties_model.PartyName);
        holder.Desc.setText(parties_model.getPartyDescription());
        try {
            Picasso.get().load(parties_model.ImageURL).into(holder.Image);
        } catch (Exception ex) {
            Toast.makeText(context, ex.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }

        DatabaseReference My_Status = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference().child("My_Status");
        DatabaseReference All_Candidates = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference().child("All_Candidates");
        DatabaseReference Candidate_Votes = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference().child("Candidate_Votes");

        holder.VoteNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Display_Dialog();
                Candidate_Votes.child(parties_model.PartyName).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Votes = snapshot.child("Votes").getValue().toString();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                My_Status.child(FirebaseAuth.getInstance().getUid()).setValue(parties_model.getPartyName());
                int t_votes = (Integer.parseInt(Votes) +1);
                Candidate_Votes.child(parties_model.PartyName).child("Votes").setValue(t_votes + "");

                Candidate_Votes.child(parties_model.getPartyName()).child("Votes").setValue(Votes).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            dialog.dismiss();
                            Intent intent = new Intent(context, Vote_Submitted.class);
                            intent.putExtra("party", parties_model.getPartyName());
                            context.startActivity(intent);
                        } else {
                            dialog.dismiss();
                            Snackbar.make(holder.VoteNow, task.getException().getLocalizedMessage(), 2000).show();
                        }
                    }
                });
            }
        });

    }

    @Override
    public int getItemCount() {
        return parties_modelArrayList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView Name, Desc;
        ImageView Image;
        Button VoteNow;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Name = itemView.findViewById(R.id.party_name);
            Desc = itemView.findViewById(R.id.party_description);
            Image = itemView.findViewById(R.id.party_image);
            VoteNow = itemView.findViewById(R.id.vote);

        }
    }

    public void Display_Dialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert);
        View v = LayoutInflater.from(context).inflate(R.layout.custom_progressdialog, null);
        alertDialog.setCancelable(false);
        alertDialog.setView(v);
        dialog = alertDialog.create();
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.show();
    }
}
