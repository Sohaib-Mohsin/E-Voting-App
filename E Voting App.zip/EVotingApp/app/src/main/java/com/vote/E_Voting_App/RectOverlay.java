package com.vote.E_Voting_App;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;

public class RectOverlay extends GraphicOverlay.Graphic{

    private int RECT_COLOR = Color.RED;
    private float STROKE_WIDTH = 4.0f;
    Paint paint_rect;

    GraphicOverlay graphicOverlay;
    Rect rect;

    public RectOverlay(GraphicOverlay graphicOverlay , Rect rect) {
        super(graphicOverlay);

        paint_rect = new Paint();
        paint_rect.setColor(RECT_COLOR);
        paint_rect.setStyle(Paint.Style.STROKE);
        paint_rect.setStrokeWidth(STROKE_WIDTH);

        this.graphicOverlay = graphicOverlay;
        this.rect = rect;
        postInvalidate();
    }

    @Override
    public void draw(Canvas canvas) {

        RectF rectF = new RectF();
        rectF.left = translateX(rectF.left);
        rectF.right = translateX(rectF.right);
        rectF.top = translateY(rectF.top);
        rectF.bottom = translateY(rectF.bottom);

        canvas.drawRect(rectF,paint_rect);

    }
}
