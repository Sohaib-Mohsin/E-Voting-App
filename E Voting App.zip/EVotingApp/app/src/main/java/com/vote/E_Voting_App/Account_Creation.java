package com.vote.E_Voting_App;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Account_Creation extends AppCompatActivity {

    EditText Name, Email, Password;
    Button CreateAccount;
    AlertDialog dialog;
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Name = findViewById(R.id.name);
        Email = findViewById(R.id.email);
        Password = findViewById(R.id.password);
        CreateAccount = findViewById(R.id.Create);

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference();

        CreateAccount.setOnClickListener(view -> {

            String U_Name = Name.getText().toString(), U_Email = Email.getText().toString(), U_Password = Password.getText().toString();

            if (TextUtils.isEmpty(U_Name) || TextUtils.isEmpty(U_Password) || !Patterns.EMAIL_ADDRESS.matcher(U_Email).matches()) {
                Toast.makeText(Account_Creation.this, "Please insert valid data!", Toast.LENGTH_LONG).show();
            } else {
                Display_Dialog();
                firebaseAuth.createUserWithEmailAndPassword(U_Email, U_Password).addOnCompleteListener(task -> {
                    if (task.isComplete()) {
                        InsertIntoDatabase(U_Name, U_Email, U_Password);
                        dialog.dismiss();
                        Toast.makeText(Account_Creation.this, "Voter registered successfully!", Toast.LENGTH_LONG).show();
                        Snackbar.make(CreateAccount, "Login to continue!", 1000).show();
                    } else {
                        dialog.dismiss();
                        Snackbar.make(CreateAccount, "Error in registration!", 1000).show();
                    }
                });
            }
        });
    }

    public void Display_Dialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Account_Creation.this, android.R.style.Theme_Material_Dialog_Alert);
        View v = getLayoutInflater().inflate(R.layout.custom_progressdialog, null);
        alertDialog.setCancelable(false);
        alertDialog.setView(v);
        dialog = alertDialog.create();
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.show();
    }

    public void InsertIntoDatabase(String name, String email, String password) {

        HashMap<String, String> map = new HashMap<>();
        map.put("Voter_Name", name);
        map.put("Voter_Email", email);
        map.put("Voter_Password", password);

        if (firebaseAuth.getUid() != null) {
            databaseReference.child("Voters").child(firebaseAuth.getUid()).setValue(map);
        }

    }

    public void Login(View view) {
        startActivity(new Intent(Account_Creation.this, Account_Login.class));
        finish();
    }
}