package com.vote.E_Voting_App;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Account_Login extends AppCompatActivity {

    EditText Email, Password;
    Button LoginToAccount;
    AlertDialog dialog;
    FirebaseAuth firebaseAuth;
    DatabaseReference My_Status;
    String Status = "Not Voted";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_login);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Email = findViewById(R.id.email);
        Password = findViewById(R.id.password);
        LoginToAccount = findViewById(R.id.Login);

        firebaseAuth = FirebaseAuth.getInstance();

        LoginToAccount.setOnClickListener(view -> {
            String U_Email = Email.getText().toString(), U_Password = Password.getText().toString();
            if (TextUtils.isEmpty(U_Password) || !Patterns.EMAIL_ADDRESS.matcher(U_Email).matches()) {
                Toast.makeText(Account_Login.this, "Please insert valid data!", Toast.LENGTH_LONG).show();
            } else {
                Display_Dialog();

                firebaseAuth.signInWithEmailAndPassword(U_Email, U_Password).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        dialog.dismiss();
                        Toast.makeText(Account_Login.this, "Voter Logged In successfully!", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(Account_Login.this, Fingerprint_Authentication.class));
                        finish();

//                        My_Status = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference().child("My_Status");
//
//                        My_Status.addValueEventListener(new ValueEventListener() {
//                            @Override
//                            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                if (snapshot.exists() && FirebaseAuth.getInstance().getUid() != null) {
//                                    Status = snapshot.child(FirebaseAuth.getInstance().getUid()).getValue().toString();
//                                    if (!Status.equals("UnVoted")) {
//                                        dialog.dismiss();
//                                        Intent intent = new Intent(Account_Login.this, Vote_Submitted.class);
//                                        intent.putExtra("party", Status);
//                                    } else {
//                                        dialog.dismiss();
//                                        Toast.makeText(Account_Login.this, "Voter Logged In successfully!", Toast.LENGTH_LONG).show();
//                                        startActivity(new Intent(Account_Login.this, Fingerprint_Authentication.class));
//                                    }
//                                    finish();
//                                } else {
//                                    dialog.dismiss();
//                                    Toast.makeText(Account_Login.this, "Voter Logged In successfully!", Toast.LENGTH_LONG).show();
//                                    startActivity(new Intent(Account_Login.this, Fingerprint_Authentication.class));
//                                }
//                            }
//
//                            @Override
//                            public void onCancelled(@NonNull DatabaseError error) {
//
//                            }
//                        });
//

                    } else {
                        dialog.dismiss();
                        Snackbar.make(LoginToAccount, "Login error!", 1000).show();
                    }
                });
            }
        });

    }

    public void Display_Dialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Account_Login.this, android.R.style.Theme_Material_Dialog_Alert);
        View v = getLayoutInflater().inflate(R.layout.custom_progressdialog, null);
        alertDialog.setCancelable(false);
        alertDialog.setView(v);
        dialog = alertDialog.create();
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.show();
    }

    public void NewUser(View view) {
        startActivity(new Intent(Account_Login.this, Account_Creation.class));
        finish();
    }
}