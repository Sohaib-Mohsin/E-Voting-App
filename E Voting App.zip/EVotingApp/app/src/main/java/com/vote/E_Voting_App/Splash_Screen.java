package com.vote.E_Voting_App;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Splash_Screen extends AppCompatActivity {

    DatabaseReference My_Status;
    String Status = "Not Voted";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        My_Status = FirebaseDatabase.getInstance("https://e-voting-android-app-default-rtdb.firebaseio.com/").getReference().child("My_Status");

        if (FirebaseAuth.getInstance().getUid() != null) {
            My_Status.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        Status = snapshot.child(FirebaseAuth.getInstance().getUid()).getValue().toString();
                        if (!Status.equals("0")) {
                            Intent intent = new Intent(Splash_Screen.this, Vote_Submitted.class);
                            intent.putExtra("party", Status);
                            finish();
                        } else {
                            startActivity(new Intent(Splash_Screen.this, Fingerprint_Authentication.class));
                            finish();
                        }
                    } else {
                        startActivity(new Intent(Splash_Screen.this, Fingerprint_Authentication.class));
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        } else {
            startActivity(new Intent(Splash_Screen.this, Account_Login.class));
            finish();
        }

    }
}
